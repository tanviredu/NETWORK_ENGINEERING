use userinfo;
create table users(user_id text(5) not null, user_name text(25));
insert into users values ('1','root');
insert into users values ('500','netadmin1');
insert into users values ('501','netadmin2');
insert into users values ('502','jsmith');
insert into users values ('504','robert');
insert into users values ('505','tax');
insert into users values ('506','income');
insert into users values ('507','expenditure');
insert into users values ('508','pat');
insert into users values ('509','');

